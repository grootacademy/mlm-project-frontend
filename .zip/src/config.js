// const IP = "localhost"
const mlm = `https://aysh.onrender.com/api/v1`;
// const mlm = `http://${IP}:4000/api/v1`;
export const config = {
    GET_ALL_PRODUCTS: `${mlm}/getProducts`,
    ADD_MEMBERSHIP_REQUEST: `${mlm}/memberdhip/request`,
    GET_TOTAL_AMOUNT: `${mlm}/getTotalAmount`,
    GET_TOTAL_USER: `${mlm}/getTotalUser`,
    GET_TOTAL_MEMBERSHIP: `${mlm}/getTotalMembership`
}