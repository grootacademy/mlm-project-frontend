export { default as AdminWithdrawals } from './admin-withdrawals-view';
