export { default as RegisterView } from './register-view';
