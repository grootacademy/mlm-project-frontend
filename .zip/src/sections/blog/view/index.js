export { default as BlogView } from './blog-view';
