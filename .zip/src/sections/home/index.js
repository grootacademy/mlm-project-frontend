/* eslint-disable import/no-unresolved */
// eslint-disable-next-line import/extensions
export { default as LoginView } from './login-view';
