// ----------------------------------------------------------------------

export const account = {
  displayName: 'Admin',
  // email: 'demo@minimals.cc',
  photoURL: '/assets/images/avatars/avatar_25.jpg',
};
